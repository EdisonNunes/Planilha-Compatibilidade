import streamlit as st
import pandas as pd
import streamlit_authenticator as stauth

senhas_criptografadas = stauth.Hasher(["123456", "123123", "333333"]).generate()

credenciais = {"usernames": {
    "lira@gmail.com": {"name": "Lira", "password": senhas_criptografadas[0]},
    "alon@gmail.com": {"name": "Alon", "password": senhas_criptografadas[1]},
    "amanda@gmail.com": {"name": "Amanda", "password": senhas_criptografadas[2]},
}}

authenticator = stauth.Authenticate(credenciais, "credenciais_hashco", "fsyfus%$67fs76AH7", cookie_expiry_days=30)

def autenticar_usuario(authenticator):
    nome, status_autenticacao, username = authenticator.login()

    if status_autenticacao:
        return {"nome": nome, "username": username}
    elif status_autenticacao == False:
        st.error("Combinação de usuário e senha inválidas")
    else:
        st.error("Preencha o formulário para fazer login")

def logout():
    authenticator.logout()


# autenticar o usuario
dados_usuario = autenticar_usuario(authenticator)

if dados_usuario:
    @st.cache_data
    def carregar_dados():
        tabela = pd.read_excel("Base.xlsx")
        return tabela

    base = carregar_dados()

    pg = st.navigation(
        {
         "Home": [st.Page("homepage.py", title="Hash&Co")],
         "Dashboards": [st.Page("dashboard.py", title="Dashboard"), st.Page("indicadores.py", title="Indicadores")],
         "Conta": [st.Page(logout, title="Sair"), st.Page("criar_conta.py", title="Criar Conta")]
         }
    )

    pg.run()